import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TeamChatService } from '../../services/team-chat.service';
import { AuthService } from '../../services/auth.service';
import { TeamLeaderService } from '../../services/manager.service';
import { Subscription, interval } from 'rxjs';

@Component({
  selector: 'app-team-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './team-chat.component.html',
  styleUrls: ['./team-chat.component.css']
})
export class TeamChatComponent implements OnInit, OnDestroy {
  team: any = null;
  members: any[] = [];
  messages: any[] = [];
  selectedParticipant: any = null; // null means 'Global Team'
  newMessage = '';
  currentUserId: number | null = null;
  isLoading = true;
  private pollSubscription?: Subscription;

  constructor(
    private teamChatService: TeamChatService,
    private authService: AuthService,
    private teamLeaderService: TeamLeaderService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.currentUserId = this.authService.getUserId();
    this.loadTeamData();
    // Refresh messages every 5 seconds
    this.pollSubscription = interval(5000).subscribe(() => this.loadMessages());
  }

  private initialMemberId: number | null = null;

  ngOnDestroy(): void {
    this.pollSubscription?.unsubscribe();
  }

  loadTeamData(): void {
    if (!this.currentUserId) return;

    this.route.queryParams.subscribe(params => {
      this.initialMemberId = params['memberId'] ? +params['memberId'] : null;
    });

    // Load official team for ID (needed for global messages)
    this.teamLeaderService.getMyTeam(this.currentUserId).subscribe({
      next: (res) => {
        this.team = res;
        this.loadMessages();
      },
      error: (err) => console.error('Error loading team', err)
    });

    // Load active collaborators (Official + Active Task assigned) for sidebar
    this.teamLeaderService.getActiveCollaborators(this.currentUserId).subscribe({
      next: (users) => {
        this.members = users || [];
        this.isLoading = false;
        
        // Auto-select member from query param if available
        if (this.initialMemberId) {
          const found = this.members.find((m: any) => m.id === this.initialMemberId);
          if (found) this.selectContact(found);
        }
      },
      error: (err) => {
        console.error('Error loading active collaborators', err);
        this.isLoading = false;
      }
    });
  }

  selectContact(member: any): void {
    this.selectedParticipant = member;
    this.messages = [];
    this.loadMessages();
  }

  loadMessages(): void {
    if (!this.team) return;

    if (this.selectedParticipant) {
      // Private chat
      this.teamChatService.getPrivateMessages(this.team.id, this.currentUserId!, this.selectedParticipant.id).subscribe({
        next: (data) => {
          this.messages = data;
          this.scrollToBottom();
          // Mark as read
          this.teamChatService.markAsRead(this.currentUserId!, this.selectedParticipant.id).subscribe();
        }
      });
    } else {
      // Global chat
      this.teamChatService.getGlobalMessages(this.team.id).subscribe({
        next: (data) => {
          this.messages = data;
          this.scrollToBottom();
        }
      });
    }
  }

  sendMessage(): void {
    if (!this.newMessage.trim() || !this.team || !this.currentUserId) return;

    const payload: any = {
      senderId: this.currentUserId,
      teamId: this.team.id,
      content: this.newMessage
    };

    if (this.selectedParticipant) {
      payload.recipientId = this.selectedParticipant.id;
    }

    console.log('DEBUG: Sending message payload:', payload);

    this.teamChatService.sendMessage(payload).subscribe({
      next: (msg) => {
        console.log('DEBUG: Message sent successfully!', msg);
        this.messages.push(msg);
        this.newMessage = '';
        this.scrollToBottom();
      },
      error: (err) => {
        console.error('DEBUG: Error sending message:', err);
        alert('Erreur lors de l\'envois du message. Vérifiez la console (F12).');
      }
    });
  }

  scrollToBottom(): void {
    setTimeout(() => {
      const container = document.getElementById('chat-container');
      if (container) container.scrollTop = container.scrollHeight;
    }, 100);
  }
}

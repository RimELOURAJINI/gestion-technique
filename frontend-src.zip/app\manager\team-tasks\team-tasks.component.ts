import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule, ActivatedRoute, Router } from '@angular/router';
import { TeamLeaderService } from '../../services/manager.service';
import { AuthService } from '../../services/auth.service';
import { Task, User, Project, Ticket } from '../../models/models';
import { TicketService } from '../../services/ticket.service';
import { TaskDetailService } from '../../services/task-detail.service';
import { ProjectSupportModalComponent } from '../../shared/project-support-modal/project-support-modal.component';
import { TaskDetailComponent } from '../../shared/task-detail/task-detail.component';

import { DragDropModule, CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';

@Component({
    selector: 'app-team-tasks',
    standalone: true,
    imports: [CommonModule, FormsModule, RouterModule, ProjectSupportModalComponent, DragDropModule, TaskDetailComponent],
    templateUrl: './team-tasks.component.html',
    styleUrl: './team-tasks.component.css'
})
export class TeamTasksComponent implements OnInit {
    tasks: Task[] = [];
    employees: User[] = [];
    projects: Project[] = [];

    selectedProjectId?: number;
    isLoading = true;
    selectedTaskId: number | null = null;

    todoTasks: Task[] = [];
    inProgressTasks: Task[] = [];
    testTasks: Task[] = [];
    doneTasks: Task[] = [];

    // Create Task form
    newTask: any = { title: '', description: '', status: 'TODO', priority: 'MEDIUM', deadline: '', type: 'FEATURE', estimatedHours: 0, actualHours: 0, qualityScore: 0, isBlocked: false, blockerReason: '' };
    selectedUserId?: number;

    // Edit Task
    editingTask: Task | null = null;

    // Support Modal
    showSupportModal = false;
    selectedSupportTask: Task | null = null;
    currentProjectForSupport: Project | null = null;

    constructor(
        private teamLeaderService: TeamLeaderService,
        private authService: AuthService,
        private ticketService: TicketService,
        private taskDetailService: TaskDetailService,
        private route: ActivatedRoute,
        private router: Router
    ) { }

    goToTaskTickets(taskId: number | undefined) {
        if (!taskId) return;
        const role = this.authService.getUserRole();
        let basePath = '/manager';
        if (role === 'ROLE_COMMERCIAL_LEADER') basePath = '/commercial-leader';
        this.router.navigate([`${basePath}/tickets`], { queryParams: { taskId: taskId } });
    }

    ngOnInit() {
        const userId = this.authService.getUserId();
        const userRole = this.authService.getUserRole();
        
        if (userId) {
            if (userRole === 'ROLE_COMMERCIAL_LEADER') {
                this.teamLeaderService.getCommercials().subscribe(res => this.employees = res);
            } else {
                this.teamLeaderService.getEmployees().subscribe(res => this.employees = res);
            }

            this.teamLeaderService.getProjectsByUserId(userId).subscribe(res => {
                this.projects = res;
                // Auto-select from query param
                this.route.queryParams.subscribe(params => {
                    this.selectedProjectId = params['projectId'] ? +params['projectId'] : (res[0]?.id ?? undefined);
                    if (this.selectedProjectId) this.loadTasks();
                    else this.isLoading = false;
                });
            });
        }
    }

    loadTasks() {
        if (!this.selectedProjectId) { this.isLoading = false; return; }
        this.isLoading = true;
        this.teamLeaderService.getTasksByProjectId(this.selectedProjectId).subscribe({
            next: (res) => { 
                this.tasks = res; 
                this.loadTicketCounts();
                this.organizeTasks(); 
                this.isLoading = false; 
            },
            error: () => this.isLoading = false
        });
    }

    loadTicketCounts() {
        // Counts are now pre-populated by the backend in the Task object
        // (notesCount and openTicketsCount)
    }

    openSupportModal(task: Task, event: Event) {
        event.stopPropagation();
        this.selectedSupportTask = task;
        this.currentProjectForSupport = this.projects.find(p => p.id === this.selectedProjectId) || null;
        this.showSupportModal = true;
    }

    closeSupportModal() {
        this.showSupportModal = false;
        this.selectedSupportTask = null;
    }

    openTaskDetail(taskId: number | undefined) {
        if (taskId) this.selectedTaskId = taskId;
    }

    closeTaskDetail() {
        this.selectedTaskId = null;
        this.loadTasks(); // Refresh list to get status/note updates if any
    }

    organizeTasks() {
        this.todoTasks = this.tasks.filter(t => t.status === 'TODO' || t.status === 'NEW' || t.status === 'PENDING' || !t.status);
        this.inProgressTasks = this.tasks.filter(t => t.status === 'IN_PROGRESS' || t.status === 'DOING');
        this.testTasks = this.tasks.filter(t => t.status === 'TEST' || t.status === 'REVIEW');
        this.doneTasks = this.tasks.filter(t => {
            const s = (t.status || '').toUpperCase();
            return s === 'DONE' || s === 'COMPLETED' || s === 'FINISHED' || s === 'TERMINE' || s === 'TERMINEE';
        });
    }

    onDrop(event: CdkDragDrop<Task[]>, newStatus: string) {
        if (event.previousContainer === event.container) {
            moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
        } else {
            const task = event.previousContainer.data[event.previousIndex];
            transferArrayItem(
                event.previousContainer.data,
                event.container.data,
                event.previousIndex,
                event.currentIndex
            );
            if (task.id) {
                this.updateStatus(task.id, newStatus);
            }
        }
    }

    getDuration(task: Task): string {
        if (!task.actualStartTime) return '';
        const end = task.actualEndTime ? new Date(task.actualEndTime) : new Date();
        const start = new Date(task.actualStartTime);
        const diffMs = end.getTime() - start.getTime();
        
        if (diffMs < 0) return '0m';
        
        const diffMins = Math.floor(diffMs / 60000);
        const hours = Math.floor(diffMins / 60);
        const mins = diffMins % 60;
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days}j ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${mins}m`;
        return `${mins}m`;
    }

    createTask() {
        if (!this.selectedUserId || !this.newTask.title) {
            alert('Veuillez renseigner le titre et choisir un employé.');
            return;
        }
        const currentUserId = this.authService.getUserId();
        const payload = { 
            ...this.newTask, 
            project: this.selectedProjectId ? { id: this.selectedProjectId } : null,
            createdBy: currentUserId ? { id: currentUserId } : null
        };
        this.teamLeaderService.addTaskToUser(+this.selectedUserId, payload).subscribe({
            next: () => { this.loadTasks(); this.resetForm(); },
            error: (err) => { console.error(err); alert('Erreur lors de la création.'); }
        });
    }

    openEditModal(task: Task) {
        this.editingTask = { ...task };
        this.newTask = {
            title: task.title,
            description: task.description || '',
            priority: task.priority,
            status: task.status,
            deadline: task.deadline ? new Date(task.deadline).toISOString().substring(0, 10) : '',
            type: task.type || 'FEATURE',
            estimatedHours: task.estimatedHours || 0,
            actualHours: task.actualHours || 0,
            qualityScore: task.qualityScore || 0,
            isBlocked: task.isBlocked || false,
            blockerReason: task.blockerReason || ''
        };
        this.selectedUserId = task.users?.[0]?.id;
    }

    updateTask() {
        if (!this.editingTask?.id || !this.newTask.title) return;
        this.teamLeaderService.updateTask(this.editingTask.id, this.newTask).subscribe({
            next: () => { this.loadTasks(); this.resetForm(); },
            error: (err) => console.error(err)
        });
    }

    saveTask() {
        if (this.editingTask) this.updateTask();
        else this.createTask();
    }

    deleteTask(taskId?: number) {
        if (!taskId || !confirm('Supprimer cette tâche ?')) return;
        this.teamLeaderService.deleteTask(taskId).subscribe(() => this.loadTasks());
    }

    updateStatus(taskId: number, status: string) {
        this.teamLeaderService.updateTaskStatus(taskId, status).subscribe(() => this.loadTasks());
    }

    resetForm() {
        this.editingTask = null;
        this.newTask = { title: '', description: '', status: 'TODO', priority: 'MEDIUM', deadline: '', type: 'FEATURE', estimatedHours: 0, actualHours: 0, qualityScore: 0, isBlocked: false, blockerReason: '' };
        this.selectedUserId = undefined;
    }

    getPriorityClass(priority: string): string {
        switch (priority) {
            case 'HIGH': return 'bg-danger';
            case 'MEDIUM': return 'bg-warning';
            case 'LOW': return 'bg-info';
            default: return 'bg-secondary';
        }
    }

    projectNameById(id: number): string {
        return this.projects.find(p => p.id === id)?.name || 'Projet';
    }
}
